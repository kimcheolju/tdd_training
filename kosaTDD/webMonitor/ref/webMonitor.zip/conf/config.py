SLACK_CHANNEL_URLS = [
'https://hooks.slack.com/services/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'
]

# 모니터링 하려는 URL, 모니터링 방법, URL 상태값
SERVICE_URLS = [
    {"NAME" : "web", "URL" : "https://google.com", "METHOD" : "GET", "RESPONSE_CODE" : 301, "STATUS" : "OK"}
]
