#!/bin/bash
docker run --rm -it --name=webMonitorDev webmonitor:dev