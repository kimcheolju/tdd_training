#!/bin/bash
docker run --restart=always -d -p 7070:7070 --name=simpleWebPython simple-web-python