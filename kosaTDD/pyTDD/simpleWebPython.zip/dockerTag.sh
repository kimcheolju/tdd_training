#!/bin/bash
docker tag simple-web-python:latest kchris000/simple-web-python:latest