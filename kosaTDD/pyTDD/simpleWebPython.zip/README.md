# simpleWebPython
Python으로 구성한 Simple Web
