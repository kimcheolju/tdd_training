#!/bin/bash
docker build -t simple-web-python .