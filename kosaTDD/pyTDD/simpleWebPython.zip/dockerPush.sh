#!/bin/bash
docker push kchris000/simple-web-python:latest